<?php
include ("../../System/Config.php");

$fonk->csrfKontrol();

$tableName="MusteriIletisim";

extract($_POST);//POST parametrelerini değişken olarak çevirir

$urunGorseliAdi=$urunSeo."_".rand(10000,99999);
$kontrol=$fonk->imageResizeUpload($_FILES['urunGorseli'],'../../../Images/Urunler/',$urunGorseliAdi,740,500,jpg);//boyutlandırmalı resim yükleme yükleme başarılı ise 1 döner

$parametreler=array(
  'musteriIletisimMusteriId' => $musteriIletisimMusteriId,
  'musteriIletisimTipi' => $musteriIletisimTipi,
  'musteriIletisimAdi' => $musteriIletisimAdi,
  'musteriIletisimTel' => $musteriIletisimTel,
  'musteriIlId' => $musteriIlId,
  'musteriIlceId' => $musteriIlceId,
  'musteriIletisimAdres' => $musteriIletisimAdres,
  'musteriIletisimKayitTarihi' => date("Y-m-d H:i:s")
);

if($kontrol==1){//eğer duruma göre boş bırakılabiliyor ise parametre, sonradan arraye eklenir
  $parametreler=array_merge($parametreler,array('urunGorseli' => $urunGorseliAdi.".jpg"));
}

if($musteriIletisimId==""){
  $fonk->logKayit(1,$tableName.' ; '.json_encode($parametreler));//1=>ekleme,2=>güncelleme,3=>silme,4=>oturum açma,5=>diğer
  ///ekleme
  $query = $db->insert($tableName, $parametreler);
}else{
  $fonk->logKayit(2,$tableName.' ; '.$musteriIletisimId.' ; '.json_encode($parametreler));//1=>ekleme,2=>güncelleme,3=>silme,4=>oturum açma,5=>diğer
  ///güncelleme
  $query = $db->update($tableName, $parametreler, [
    "musteriIletisimId" => $musteriIletisimId
  ]);
}

if ($query){
  echo '1';
}
?>
