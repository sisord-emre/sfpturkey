<?php
include ("../../System/Config.php");
$primaryId=$_POST['Id'];
?>
<div class="card-body">
  <div class="row">
    <div class="col-12">
      <div class="card">
        <div class="card-content collapse show">
          <div class="table-responsive">
            <table class="table table-bordered table-striped">
              <thead>
                <tr>
                  <th>#</th>
                  <th><?=$fonk->getPDil("Tipi")?></th>
                  <th><?=$fonk->getPDil("Adı")?></th>
                  <th><?=$fonk->getPDil("Telefon")?></th>
                  <th><?=$fonk->getPDil("İl/İlçe")?></th>
                  <th><?=$fonk->getPDil("Adres")?></th>
                  <th><?=$fonk->getPDil("Kayit Tarihi")?></th>
                  <th style="width:235px;"><?=$fonk->getPDil("İslem")?></th>
                </tr>
              </thead>
              <tbody>
                <?php
                $list = $db->select("MusteriIletisim", [
                  "[>]il" => ["MusteriIletisim.musteriIlId" => "ilId"],
                  "[>]ilce" => ["MusteriIletisim.musteriIlceId" => "ilceId"]
                ],"*",[
                  "musteriIletisimMusteriId" => $primaryId
                ]);
                $satir=0;
                foreach($list as $item){
                  $satir++;
                  ?>
                  <tr id="satirAltBirim_<?=$item['musteriIletisimId']?>">
                    <th scope="row"><?=$satir?></th>
                    <td><?php if($item['musteriIletisimTipi']==1){ echo "Merkez"; } else { echo "Şube"; }?></td>
                    <td><?=$item['musteriIletisimAdi']?></td>
                    <td><?=$item['musteriIletisimTel']?></td>
                    <td><?=$item['ilAdi'].'/'.$item['ilceAdi']?></td>
                    <td><?=$item['musteriIletisimAdres']?></td>
                    <td><?=$fonk->sqlToDatetime($item['musteriIletisimKayitTarihi'])?></td>
                    <td>
                      <button type="button" onclick="altBirimGuncelle('<?=$item['musteriIletisimId']?>','<?=$item['musteriIletisimTipi']?>','<?=$item['musteriIletisimAdi']?>','<?=$item['musteriIletisimTel']?>','<?=$item['musteriIlId']?>','<?=$item['musteriIlceId']?>','<?=$item['musteriIletisimAdres']?>');" class="btn btn-warning btn-sm"><i class="la la-upload"></i> <?=$fonk->getPDil("Güncelle")?></button>
                      <button type="button" onclick="altBirimSil('<?=$item['musteriIletisimId']?>');" class="btn btn-danger btn-sm"><i class="la la-trash-o"></i> <?=$fonk->getPDil("Sil")?></button>
                    </td>
                  </tr>
                <?php } ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
