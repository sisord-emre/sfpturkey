<?php
if($primaryId!=""){
  ?>
  <!-- Alt Birim -->
  <section id="sizing">
    <div class="row">
      <div class="col-md-12">
        <div class="card">
          <div class="card-header">
            <h4 class="card-title pointer" data-toggle="collapse" data-target="#altBirimDiv"><?=$fonk->getPDil("Müşteri İletişim Bilgileri")?></h4>
            <a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>

            <div class="heading-elements">
              <ul class="list-inline mb-0">
                <li><button type="button" onclick="altBirimModal();" class="btn btn-success btn-sm" style="padding: 0.2rem 0.75rem;"><i class="la la-plus"></i> <?=$fonk->getPDil("Yeni Ekle")?></button></li>
                <li><a data-toggle="collapse" data-target="#altBirimDiv"><i class="la la-arrows-v"></i></a></li><!-- id leri unutma -->
              </ul>
            </div>
          </div>
          <div class="card-content collapse" id="altBirimDiv"><!-- id leri unutma  liste açık gelmesini istiyorsan collapse "show"  ekle gizli gelmesini istiyorsahn "show" kaldır -->
            <div id="altBirimList"><!-- Listeleme Gelicek --> </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- ekleme -->
  <div class="modal fade text-left" id="altBirimEkle" role="dialog" aria-hidden="true"><!-- id leri unutma -->
    <!-- ekleme modalı -->
    <div class="modal-dialog modal-lg" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title"><?=$fonk->getPDil("İletişim Bilgi Ekle")?></h4>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="card-body">
          <form id="altBirimPost" class="form" action="" method="post">
            <div class="row">
              <div class="col-md-6">
                <div class="form-group" style="width:100%!important">
                  <label for="userinput1"><?=$fonk->getPDil("Birim Tipi")?></label>
                  <select class="select2 form-control block" name="musteriIletisimTipi" id="musteriIletisimTipi" style="width:100%!important" required>
                    <option value=""><?=$fonk->getPDil("Seçiniz")?></option>
                    <?php
                    $sorguList = $db->select("MusteriIletisimTipleri", "*");
                    foreach($sorguList as $sorgu){
                      ?>
                      <option value="<?=$sorgu['mustreriIletisimTipId']?>"><?=$sorgu['mustreriIletisimTipAdi']?></option>
                    <?php } ?>
                  </select>
                </div>
              </div>
              <div class="col-md-6">
                <div class="form-group">
                  <label for="musteriIletisimAdi"><?=$fonk->getPDil("Adı")?></label>
                  <input type="text" id="musteriIletisimAdi" class="form-control border-primary" placeholder="<?=$fonk->getPDil("Adı")?>" name="musteriIletisimAdi" autocomplete="off" required>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-md-6">
                <div class="form-group" style="width:100%!important">
                  <label for="userinput1"><?=$fonk->getPDil("İl")?></label>
                  <select class="select2 form-control block" name="musteriIlId" id="musteriIlId" style="width:100%!important" required>
                    <option value=""><?=$fonk->getPDil("Seçiniz")?></option>

                  </select>
                </div>
              </div>
              <div class="col-md-6">
                <div class="form-group" style="width:100%!important">
                  <label for="userinput1"><?=$fonk->getPDil("İlçe")?></label>
                  <select class="select2 form-control block" name="musteriIlceId" id="musteriIlceId" style="width:100%!important" required>
                    <option value=""><?=$fonk->getPDil("Seçiniz")?></option>

                  </select>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-md-6">
                <div class="form-group">
                  <label for="musteriIletisimTel"><?=$fonk->getPDil("Tel")?></label>
                  <input type="tel" id="musteriIletisimTel" class="form-control border-primary" placeholder="<?=$fonk->getPDil("Tel")?>" name="musteriIletisimTel" autocomplete="off" required>
                </div>
              </div>
              <div class="col-md-6">
                <div class="form-group">
                  <label for="userinput1"><?=$fonk->getPDil("Adres")?></label>
                  <textarea class="form-control" id="musteriIletisimAdres" rows="3" name="musteriIletisimAdres" placeholder="..."></textarea>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-md-12">
                <div class="form-group" style="text-align: center;margin-top:10px">
                  <input type="hidden" name="musteriIletisimMusteriId" id="musteriIletisimMusteriId" value="<?=$primaryId?>" />
                  <input type="hidden" name="musteriIletisimId" id="musteriIletisimId" /><!-- update ise doludur -->
                  <input type="hidden" name="token" value="<?=$_SESSION['token']?>" />
                  <button type="submit" class="btn btn-success" id="altBirimButton"><i class="la la-floppy-o"></i> <?=$fonk->getPDil("Kayıt")?></button>
                </div>
              </div>
            </div>
          </form>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn grey btn-outline-secondary" data-dismiss="modal"><?=$fonk->getPDil("Kapat")?></button>
        </div>
      </div>
    </div>
  </div>

  <script  type="text/javascript">
  $(document).ready(function(){
    altBirimListele(<?=$primaryId?>);
  });
  </script>
<!-- /Alt Birim -->

<?php } ?>

<script type="text/javascript">
////// Alt Birim İşlemler
$('#altBirimPost').submit(function (e) {
  document.getElementById('altBirimButton').disabled=true;
  e.preventDefault(); //submit postu kesyoruz
  var data=new FormData(this);
  $('#altBirimList').html('<img src="Images/loading.gif" style="position:relative;left:50%;margin-top:10%;width:64px">');
  $.ajax({
    type: "POST",
    url: "Pages/Musteriler/altBirimEkle.php",
    data:data,
    contentType:false,
    processData:false,
    success: function(res){
      document.getElementById('altBirimButton').disabled=false;
      if(res==1){
        altBirimListele(<?= $primaryId ?>);
        altBirimTemizle();
      }else{
        alert('<?=$fonk->getPDil("Kayıt Esnasında Bir Hata Oluştu")?>');
      }
    }
  });
});

function altBirimSil(silID){
  if(confirm('<?=$fonk->getPDil("Silmek İstediğinize Emin misiniz ?")?>')) {
    $.ajax({
      type: "POST",
      url: "Pages/Musteriler/altBirimSil.php",
      data:{'silID':silID},
      success: function(res){
        if(res==1){
          document.getElementById("satirAltBirim_"+silID).style.display = "none";
        }
      }
    });
  }
}

function altBirimListele(Id){
  $.ajax({
    type: "POST",
    url: "Pages/Musteriler/altBirimList.php",
    data:{'Id':Id},
    success: function(res){
      $('#altBirimList').html(res);
    }
  });
}

function altBirimGuncelle(musteriIletisimId,musteriIletisimTipi,musteriIletisimAdi,musteriIletisimTel,musteriIlId,musteriIlceId,musteriIletisimAdres){
  document.getElementById("musteriIletisimId").value=musteriIletisimId;
  $('#musteriIletisimTipi').val(musteriIletisimTipi).trigger('change');
  $('#musteriIlId').val(musteriIlId).trigger('change');
  setTimeout(() => {
    $('#musteriIlceId').val(musteriIlceId).trigger('change');
  },500);
  document.getElementById("musteriIletisimAdi").value = musteriIletisimAdi;
  document.getElementById("musteriIletisimTel").value = musteriIletisimTel;
  document.getElementById("musteriIletisimAdres").value = musteriIletisimAdres;
  $("#altBirimEkle").modal("show");
}

function altBirimModal(){
  altBirimTemizle();
  $("#altBirimEkle").modal("show");
}

function altBirimTemizle(){
  $('#musteriIletisimTipi').val('').trigger('change');
  $('#musteriIlceId').val('').trigger('change');
  $('#musteriIlId').val('').trigger('change');
  document.getElementById("musteriIletisimAdi").value = "";
  document.getElementById("musteriIletisimTel").value = "";
  document.getElementById("musteriIletisimAdres").value = "";
  document.getElementById("musteriIletisimId").value = "";
}

$(document.body).on("change","#musteriIlId",async function(){
  await ilIlce('musteriIlId','musteriIlceId');
});
////// -Alt Birim İşlemler

</script>
