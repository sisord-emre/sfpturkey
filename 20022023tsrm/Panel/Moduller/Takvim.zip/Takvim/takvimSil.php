<?php
include ("../../System/Config.php");

///Loglama İşlemi
if($sabitB['sabitBilgiLog']==1){
  $logSilme = $db->get("Seanslar", "*", [
    "seansId" => $_POST['sil']
  ]);
  $fonk->logKayit(3,'Seanslar ; '.json_encode($logSilme));//1=>ekleme,2=>güncelleme,3=>silme,4=>oturum açma,5=>diğer
}

$sil = $db->delete("Seanslar", [
  "seansId" => $_POST['sil']
]);

if($sil){//uyarı metinleri
  echo "1";
}
?>
