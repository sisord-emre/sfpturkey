<?php
include ("../../System/Config.php");

$fonk->csrfKontrol();

$primaryId=$_POST['update'];
$seansMusteriHizmetId=$_POST['seansMusteriHizmetId'];
$seansTarihi=$_POST['seansTarihi'];
$seansBaslangicSaat=$_POST['seansBaslangicSaat'];
$seansBitisSaat=$_POST['seansBitisSaat'];
$seansAciklama=$_POST['seansAciklama'];


if($primaryId!=""){
	//günclelemedeki parametreler
	$parametreler=array(
		'seansMusteriHizmetId' => $seansMusteriHizmetId,
		'seansTarihi' => $seansTarihi,
		'seansBaslangicSaat' => $seansBaslangicSaat,
		'seansBitisSaat' => $seansBitisSaat,
		'seansTipi' => 1,
		'seansAciklama' => $seansAciklama
	);
}else{
	//eklemedeki parametreler
	$parametreler=array(
		'seansMusteriHizmetId' => $seansMusteriHizmetId,
		'seansTarihi' => $seansTarihi,
		'seansBaslangicSaat' => $seansBaslangicSaat,
		'seansBitisSaat' => $seansBitisSaat,
		'seansTipi' => 1,
		'seansAciklama' => $seansAciklama,
		'seansKayitTarihi' => date("Y-m-d H:i:s")
	);
}


if($primaryId!=""){
	$fonk->logKayit(2,"Seanslar".' ; '.$primaryId.' ; '.json_encode($parametreler));//1=>ekleme,2=>güncelleme,3=>silme,4=>oturum açma,5=>diğer
	///güncelleme
	$query = $db->update("Seanslar", $parametreler, [
    "seansId" => $primaryId
  ]);
}
else{
	$fonk->logKayit(1,"Seanslar".' ; '.json_encode($parametreler));//1=>ekleme,2=>güncelleme,3=>silme,4=>oturum açma,5=>diğer
	///ekleme
	$db->insert("Seanslar", $parametreler);
}

if ($query) {
	echo "1";
}
?>
