<?php
include ("../../System/Config.php");

$menuId=$_POST['menuId'];//tabloadı istenirse burdan değiştirilebilir

///menu bilgileri alınıyor
$hangiMenu = $db->get("Menuler", "*", [
	"menuUstMenuId" => $menuId,
	"menuOzelGorunuruk" =>	1,
	"menuTipi" =>	2 //kayıt için 1 listeleme için 2 diğer sayfalar içim 3 yazılmalı****
]);

for($i=0;$i<Count($kullaniciYetkiler);$i++){//kullanıcının yetkilerini sorguluyoruz
	$kullaniciYetki= json_decode($kullaniciYetkiler[$i], true);

	if($kullaniciYetki['menuYetkiID']==$menuId){//menu id

		if($kullaniciYetki['listeleme']=="on")
		{$listelemeYetki=true;}//listeleme

		if($kullaniciYetki['ekleme']=="on")
		{$eklemeYetki=true;}//ekleme

		if($kullaniciYetki['silme']=="on")
		{$silmeYetki=true;}//silme

		if($kullaniciYetki['duzenleme']=="on")
		{$duzenlemeYetki=true;}//duzenleme

		if($kullaniciYetki['excel']=="on")
		{$tamExcelYetki=true;}//tam excel
	}
}
if(!$listelemeYetki)
{
	//yetki yoksa gözükecek yazi
	echo '<div class="alert alert-icon-right alert-warning alert-dismissible mb-2" role="alert">
	<span class="alert-icon"><i class="la la-warning"></i></span>
	<button type="button" class="close" data-dismiss="alert" aria-label="Close">
	<span aria-hidden="true">×</span>
	</button>
	<strong>'.$fonk->getPDil("Yetki!").' </strong> '.$fonk->getPDil("Bu Menüye Erişim Yetkiniz Bulunmamaktadır.").'
	</div>';
}
else{//Listeleme Yetkisi Var

	$tableName=$hangiMenu['menuTabloAdi'];//tabloadı istenirse burdan değiştirilebilir

	$tabloPrimarySutun=$hangiMenu['menuTabloPrimarySutun'];//primarykey sutunu

	$baslik=$hangiMenu['menuAdi'];//başlıkta gözükecek yazı menu adi

	$duzenlemeSayfasi=$tableName.'/'.strtolower($tableName).'Kayit.php';
	$detaysayfasi=$tableName.'/'.strtolower($tableName).'Detay.php';

	if($_POST['sil']==""){
		//sayfayı görüntülenme logları
		$fonk->logKayit(6,$_SERVER['REQUEST_URI']);//1=>ekleme,2=>güncelleme,3=>silme,4=>oturum açma,5=>diğer
	}

	///silme
	if($_POST['sil']!="" && $silmeYetki){

		///Loglama İşlemi
		if($sabitB['sabitBilgiLog']==1){
			$logSilme = $db->get($tableName, "*", [
				$tabloPrimarySutun => $_POST['sil']
			]);
			$fonk->logKayit(3,$tableName.' ; '.json_encode($logSilme));//1=>ekleme,2=>güncelleme,3=>silme,4=>oturum açma,5=>diğer
		}

		$sil = $db->delete($tableName, [
			$tabloPrimarySutun => $_POST['sil']
		]);

		if($sil){//uyarı metinleri
			echo 1;
			exit;
		}
		else{
			echo '
			<div class="alert alert-danger alert-dismissible mb-2" role="alert">
			<button type="button" class="close" data-dismiss="alert" aria-label="Close">
			<span aria-hidden="true">×</span>
			</button>
			<strong>'.$fonk->getPDil("Hata!").' </strong> '.$fonk->getPDil("Silme Esnasında Bir Hata Oluştu. Lütfen Tekrar Deneyiniz.").'
			</div>';
		}
	}
	echo "<script>$('#ustYazi').html('&nbsp;-&nbsp;'+'".$baslik."');</script>";//Başlık Güncelleniyor
	$listeleme = $db->select($tableName, "*", [
		"ORDER" => [
			$tabloPrimarySutun => "DESC",
		]
	]);

	//****** tam excel alma bas
	$sayac=1;
	$ExportData[0]=array('Ad Soyad','Email');///başlıklar
	foreach ($listeleme as $satir) {//içerikler

		$ExportData[$sayac]=array($satir['kullaniciAdSoyad'],$satir['kullaniciEmail']);
		$sayac++;
	}
	$_SESSION["excel"]=$ExportData;
	$_SESSION["excelTablo"]=$tableName;
	//****** tam excel alma bitis
	$tamExcelYetki=false;
	?>
	<!-- HTML5 export buttons table -->
	<section id="html5">
		<div class="row">
			<div class="col-12">
				<div class="card">
					<div class="card-header">
						<h4 class="card-title"><?=$fonk->getPDil($baslik)?></h4>
						<a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>
						<div class="heading-elements">
							<?php if($tamExcelYetki){?>
								<a href="Pages/excel.php" class="btn mr-1 mb-1 btn-outline-warning btn-sm"><i class="la la-print"></i> <?=$fonk->getPDil("Tam Excel")?></a>
							<?php } ?>
						</div>
					</div>
					<div class="card-content collapse show">
						<div class="card-body card-dashboard" id="takvimList">
							<!-- Takvim -->
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!--/ HTML5 export buttons table -->

	<!-- detay modalı -->
	<div id="detaylari">

	</div>

<?php } include("../../Scripts/listelemeJs.php");?>

<script type="text/javascript">
$(document).ready(function(){
	$('#takvimList').fullCalendar({
		locale: 'tr', // the initial locale
		header: {
			left: 'prev,next today',
			center: 'title',
			right: 'month,agendaWeek,agendaDay'
		},
		defaultDate: '<?=date('Y-m-d');?>',
		businessHours: false,
		editable: false,//sürükle brakı açmak için true
		firstDay: 1,
		hiddenDays: [0],//gün gizleme
		timeFormat: 'H:mm', // uppercase H for 24-hour clock
		events: [
			<?php
			$takvimList = $db->select("Seanslar", [
				"[>]MusteriHizmetleri" => ["Seanslar.seansMusteriHizmetId" => "musteriHizmetId"],
				"[>]Musteriler" => ["MusteriHizmetleri.musteriHizmetMusteriId" => "musteriId"],
				"[>]Hizmetler" => ["MusteriHizmetleri.musteriHizmetHizmetId" => "hizmetId"]
			],"*");
			foreach ($takvimList as $value) {
				?>
				{
					id: '<?=$value['seansId']?>',
					title: '<?=" Müşteri: ".$value['musteriKodu']." - ".$value['musteriAdSoyad'].", Hizmet: ".$value['hizmetAdi']?>',
					url: 'javascript:takvimDuzenle("<?=$value['seansId']?>","<?=$value['seansTarihi']?>")',
					start: '<?=$value['seansTarihi']?> <?=$value['seansBaslangicSaat']?>',
					end: '<?=$value['seansTarihi']?> <?=$value['seansBitisSaat']?>',
					overlap: false
				},
				<?php } ?>
			],
			dayClick: function(date, jsEvent, view) {
				takvimDuzenle("",date.format());
			},
			eventMouseover: function(event, jsEvent, view) {
				if (view.name !== 'agendaDay') {
					$(jsEvent.target).attr('title', event.title);
				}
			}
		});
	});

	function takvimDuzenle(primaryId,seansTarihi){
		$.ajax({
			type: "POST",
			url: "Pages/Seanslar/takvimBilgi.php",
			data:{'primaryId':primaryId,'seansTarihi':seansTarihi},
			success: function(res){
				$('#detaylari').html(res);
				$("#fadeIn").modal("show");
			},
			error: function (jqXHR, status, errorThrown) {
				alert("Result: "+status+" Status: "+jqXHR.status);
			}
		});
	}

	function takvimSil(sil){
		if(confirm('Silmek İstediğinize Emin misiniz ?')) {
			$.ajax({
				type: "POST",
				url: "Pages/Seanslar/takvimSil.php",
				data:{'sil':sil},
				success: function(res){
					if (res==1) {
						$("#fadeIn").modal("hide");
						$('#takvimList').fullCalendar('removeEvents',sil);
					}else {
						alert(res);
					}
				},
				error: function (jqXHR, status, errorThrown) {
					alert("Result: "+status+" Status: "+jqXHR.status);
				}
			});
		}
	}
</script>
