<?php
include ("../../System/Config.php");

$primaryId=$_POST['primaryId'];

//sayfayı görüntülenme logları
$fonk->logKayit(6,$_SERVER['REQUEST_URI']."?primaryId=".$primaryId);//1=>ekleme,2=>güncelleme,3=>silme,4=>oturum açma,5=>diğer

if($primaryId!=""){
	$Listeleme = $db->select("Seanslar", [
		"[>]MusteriHizmetleri" => ["Seanslar.seansMusteriHizmetId" => "musteriHizmetId"]
	],"*",[
		"seansId" => $primaryId
	]);
}
?>
<div class="modal fade text-left" id="fadeIn" tabindex="-1" role="dialog" aria-hidden="true">
	<!-- detay modalı -->
	<div class="modal-dialog modal-lg" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h4 class="modal-title" id="baslikModal"><?=$fonk->getPDil("Randevu & Seans Bilgileri")?></h4>
				<?php if($primaryId!=""){ ?>
					<a href="javascript:takvimSil('<?=$primaryId?>');" style="margin-left: 1rem;color:red"><i class="la la-trash" style="font-size: 1.5rem;"></i></a>
				<?php } ?>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<div class="modal-body" id="icerikModal">

				<!-- Güncellenecek Kısımlar -->
				<form id="formpost" class="form" action="" method="post">
					<div class="form-body">

						<!-- Güncellenecek Kısımlar -->
						<div class="row">
							<div class="col-md-6">
								<div class="form-group">
									<label for="userinput1"><?=$fonk->getPDil("Müşteriler")?></label>
									<select class="select2 form-control block" name="musteriHizmetMusteriId" id="musteriHizmetMusteriId" onchange="musteriToHizmet()" style="width:100%" required>
										<option value=""><?=$fonk->getPDil("Seçiniz")?></option>
										<?php
										$sorguList = $db->select("Musteriler", [
											"[>]il" => ["Musteriler.musteriIlId" => "ilId"],
											"[>]ilce" => ["MusteriIletisim.musteriIlceId" => "ilceId"]
										],"*");
										foreach($sorguList as $sorgu){
											?>
											<option value="<?=$sorgu['musteriId']?>" <?if($sorgu['musteriId']==$Listeleme['musteriHizmetMusteriId']){echo " selected";}?>><?=$sorgu['musteriKodu']." - ".$sorgu['musteriAdSoyad']?></option>
										<?php }?>
									</select>
								</div>
							</div>
							<div class="col-md-6">
								<div class="form-group">
									<label for="userinput1"><?=$fonk->getPDil("Müşteri Hizmetleri")?></label>
									<select class="select2 form-control block" name="seansMusteriHizmetId" id="seansMusteriHizmetId" style="width:100%" required>
										<option value=""><?=$fonk->getPDil("Seçiniz")?></option>
										<?php
										$sorguList = $db->select("MusteriHizmetleri", [
											"[>]Hizmetler" => ["MusteriHizmetleri.musteriHizmetHizmetId" => "hizmetId"]
										],"*",[
											"musteriHizmetMusteriId" => $Listeleme['musteriHizmetMusteriId']
										]);
										foreach($sorguList as $sorgu){
											?>
											<option value="<?=$sorgu['musteriHizmetId']?>" <?if($sorgu['musteriHizmetId']==$Listeleme['seansMusteriHizmetId']){echo " selected";}?>><?=$sorgu['hizmetAdi']." => Toplam Seans: ".$sorgu['musteriHizmetSeansSayisi']?></option>
										<?php }?>
									</select>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-6">
								<div class="form-group">
									<label for="seansBaslangicSaat"><?=$fonk->getPDil("Başlangıç Saati")?></label>
									<input type="time" id="seansBaslangicSaat" class="form-control border-primary" name="seansBaslangicSaat" value="<?=$Listeleme['seansBaslangicSaat']?>" autocomplete="off" required>
								</div>
							</div>
							<div class="col-md-6">
								<div class="form-group">
									<label for="seansBitisSaat"><?=$fonk->getPDil("Bitiş Saati")?></label>
									<input type="time" id="seansBitisSaat" class="form-control border-primary" name="seansBitisSaat" value="<?=$Listeleme['seansBitisSaat']?>" autocomplete="off" required>
								</div>
							</div>
						</div>

						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
									<label for="seansAciklama"><?=$fonk->getPDil("Açıklama")?></label>
									<textarea class="form-control" id="seansAciklama" rows="5" name="seansAciklama"  placeholder="..."><?=$Listeleme['seansAciklama']?></textarea>
								</div>
							</div>
						</div>

						<!-- /Güncellenecek Kısımlar -->

					</div>
					<div class="form-group" style="text-align: center;margin-top:15px">
						<input type="hidden" name="update" value="<?=$primaryId?>"/>
						<input type="hidden" name="seansTarihi" value="<?=$_POST["seansTarihi"]?>"/>
						<input type="hidden" name="token" value="<?=$_SESSION['token']?>" />
						<button type="submit" class="btn mb-1 btn-success"><i class="la la-floppy-o"></i> <?php if($primaryId!=""){ echo $fonk->getPDil("Güncelle");}else{ echo $fonk->getPDil("Kayıt");}?></button>
					</div>
				</form>
				<!-- /Güncellenecek Kısımlar -->

			</div>
			<div class="modal-footer">
				<button type="button" class="btn grey btn-outline-secondary" data-dismiss="modal"><?=$fonk->getPDil("Kapat")?></button>
			</div>
		</div>
	</div>
</div>

<?php include("../../Scripts/kayitJs.php");?>
<script type="text/javascript">
function musteriToHizmet(){
	var musteriHizmetMusteriId = $('#musteriHizmetMusteriId').val();
	$.ajax({
		type: "POST",
		url: "Scripts/musteriToHizmet.php",
		data: {
			'musteriHizmetMusteriId': musteriHizmetMusteriId
		},
		success: function(data) {
			$('#seansMusteriHizmetId').empty();
			$('#seansMusteriHizmetId').append(data);
		}
	});
}

$('#formpost').submit(function (e) {
	e.preventDefault(); //submit postu kesyoruz
	var data=new FormData(this);
	$.ajax({
		type: "POST",
		url: "Pages/Seanslar/takvimKayit.php",
		data:data,
		contentType:false,
		processData:false,
		success: function(res){
			if (res==1) {
				$("#fadeIn").modal("hide");
				setTimeout(function(){
					SayfaYenile();
				}, 700);
			}else {
				alert(res);
			}
		},
		error: function (jqXHR, status, errorThrown) {
			alert("Result: "+status+" Status: "+jqXHR.status);
		}
	});
});
</script>
