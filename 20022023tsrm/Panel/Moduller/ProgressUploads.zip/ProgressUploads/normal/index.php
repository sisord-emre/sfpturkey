<!doctype html>
<html>
<head>

  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
  <!--<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.form/4.2.2/jquery.form.js"></script>-->

</head>
<body>
  <form method="post" action="upload.php"  id="formpost">
    <input type='file' name='file' />
    <input type='submit' value='Upload' onclick='upload_image();'>
  </form>

  <div class="progress">
    <div class="progress-bar progress-bar-striped active" id="progressBarUpdate" role="progressbar" aria-valuemin="0" aria-valuemax="100" style="width:0%">
      <span id="yazi">0%</span>
    </div>
  </div>

  <div id="output">

  </div>

  <script>
  function upload_image()
  {
    var bar = $('#progressBarUpdate');
    var percent = $('#yazi');

    $('#formpost').submit(function (e) {
      e.preventDefault(); //submit postu kesyoruz

      var data=new FormData(this);
      $.ajax({
        type: "POST",
        url: "upload.php",
        data:data,
        contentType:false,
        processData:false,
        beforeSend: function() {
          var percentVal = '0%';
          bar.width(percentVal)
          percent.html(percentVal);
        },
        xhr: function() {
          var xhr = new window.XMLHttpRequest();
          xhr.upload.addEventListener("progress", function(evt) {
            if (evt.lengthComputable) {
              var percentComplete = (evt.loaded / evt.total) * 100;
              var percentVal = parseInt(percentComplete) + '%';
              bar.width(percentVal)
              percent.html(percentVal);
            }
          }, false);
          return xhr;
        },
        success: function(){
          var percentVal = '100%';
          bar.width(percentVal)
          percent.html(percentVal);
        },
        complete: function(gelenSayfa) {
          percentVal = '0%';
          bar.width(percentVal)
          percent.html(percentVal);
          document.getElementById("output").innerHTML=gelenSayfa.responseText;
        }
      });
    });

  }

  /*//ajax.form.js ile kullanım
  function upload_image()
  {
  var bar = $('#progressBarUpdate');
  var percent = $('#yazi');

  $('#formpost').ajaxForm({
  beforeSubmit: function() {
  var percentVal = '0%';
  bar.width(percentVal)
  percent.html(percentVal);
},

uploadProgress: function(event, position, total, percentComplete) {
var percentVal = percentComplete + '%';
bar.width(percentVal)
percent.html(percentVal);
},

success: function() {
var percentVal = '100%';
bar.width(percentVal)
percent.html(percentVal);
},
complete: function(xhr) {
if(xhr.responseText)
{
percentVal = '0%';
bar.width(percentVal)
percent.html(percentVal);
document.getElementById("output_image").innerHTML=xhr.responseText;
}
}

});
}*/
</script>
</body>
</html>
