<?php
function videoUpload($dosya,$hedef,$videoAdi,$maxSizeMb){

	$maxsize = $maxSizeMb*1048576;

	// Select file type
	$videoUzanti = strtolower(pathinfo($hedef.$dosya["name"],PATHINFO_EXTENSION));

	$target_file = $hedef . $videoAdi.'.'.$videoUzanti;

	// Valid file extensions
	$desteklenenler = array("mp4","avi","3gp","mov","mpeg");

	// Check extension
	if(in_array($videoUzanti,$desteklenenler)){
		
		// Check file size
		if(($dosya['size'] >= $maxsize) || ($dosya["size"] == 0)) {
			return "Dosya Boyutu Çok Yüksek.";
		}else{
			// Upload
			if(move_uploaded_file($dosya['tmp_name'],$target_file)){
				return 1;
			}
		}
	}
	else{
		return "Desteklenmeyen Dosya Tipi.";
	}

}


$kontrol=videoUpload($_FILES['file'],"upload/","test2",6);

if($kontrol==1){
	echo "success";
}else{
	echo $kontrol;
}
?>
