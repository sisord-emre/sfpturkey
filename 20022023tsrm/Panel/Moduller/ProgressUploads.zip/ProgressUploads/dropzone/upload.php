<?php
$dosya=$_FILES['file'];
$hedef=$_POST['dosyaHedef'];
$dosyaAdi=$_POST['dosyaAdi'];

// Select file type
$dosyaUzanti = strtolower(pathinfo($hedef.$dosya["name"],PATHINFO_EXTENSION));

$target_file = $hedef . $dosyaAdi.'.'.$dosyaUzanti;

// Upload
if(move_uploaded_file($dosya['tmp_name'],$target_file)){
	echo $dosyaAdi.'.'.$dosyaUzanti;
}
else{
	echo "hata";
}
?>
