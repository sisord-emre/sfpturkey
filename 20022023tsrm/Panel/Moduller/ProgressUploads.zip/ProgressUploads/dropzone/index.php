<!DOCTYPE html>
<html class="loading" lang="tr" data-textdirection="ltr">
<!-- BEGIN: Head-->
<head>

  <!-- BEGIN: Vendor CSS-->
  <link rel="stylesheet" type="text/css" href="assets/vendors/css/vendors.min.css">

  <link rel="stylesheet" type="text/css" href="assets/vendors/css/file-uploaders/dropzone.min.css">

  <!-- BEGIN: Theme CSS-->
  <link rel="stylesheet" type="text/css" href="assets/css/bootstrap.css">
  <link rel="stylesheet" type="text/css" href="assets/css/bootstrap-extended.css">
  <link rel="stylesheet" type="text/css" href="assets/css/colors.css">
  <link rel="stylesheet" type="text/css" href="assets/css/components.css">
  <!-- END: Theme CSS-->

  <!-- END: Vendor CSS-->
  <link rel="stylesheet" type="text/css" href="assets/css/plugins/file-uploaders/dropzone.css">
  <link rel="stylesheet" type="text/css" href="assets/css/pages/dropzone.css">
  <!-- END: Page CSS-->


</head>
<!-- END: Head-->

<!-- BEGIN: Body-->

<body class="vertical-layout vertical-menu 2-columns   fixed-navbar" data-open="click" data-menu="vertical-menu" data-col="2-columns">


  <section id="dropzone-examples">
    <div class="row">
      <div class="col-12">
        <div class="card">
          <div class="card-header">
            <h4 class="card-title">Remove All Thumbnails</h4>
            <a class="heading-elements-toggle"><i class="la la-ellipsis-h font-medium-3"></i></a>
            <div class="heading-elements">
              <ul class="list-inline mb-0">
                <li><a data-action="collapse"><i class="ft-minus"></i></a></li>
                <li><a data-action="reload"><i class="ft-rotate-cw"></i></a></li>
                <li><a data-action="close"><i class="ft-x"></i></a></li>
              </ul>
            </div>
          </div>
          <div class="card-content collapse show">
            <div class="card-body">
              <p class="card-text">This example allows user to create a button that will remove all files from a dropzone. Hear for the button's click event and then call <code>removeAllFiles</code> method to remove all the files from the dropzone.</p>
              <button id="clear-dropzone" class="btn btn-primary mb-1"><i class="ft-trash"></i> Temizle</button>
              <form action="upload.php" class="dropzone dropzone-area" id="dpz-remove-all-thumb" method="post">
                <input type="hidden" name="dosyaHedef" value="upload/">
                <input type="hidden" name="dosyaAdi" value="deneme">
                <div class="dz-message">Yüklenecek Dosyaları Seçiniz</div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- END: Content-->


  <!-- BEGIN: Vendor JS-->
  <script src="assets/vendors/js/vendors.min.js"></script>
  <!-- BEGIN Vendor JS-->

  <!-- BEGIN: Page Vendor JS-->
  <script src="assets/vendors/js/extensions/dropzone.min.js"></script>
  <!-- END: Page Vendor JS-->

  <script>
  Dropzone.options.dpzRemoveAllThumb = {
    paramName: "file", // The name that will be used to transfer the file
    //acceptedFiles: "image/jpeg,image/png,image/gif",
    maxFilesize: 6, // MB
    thumbnailWidth: "100",
    thumbnailHeight: "100",
    addRemoveLinks: true,//altında tek tek silmek için button olsunmu
    dictCancelUpload: "Cancel",//yükleme yaparken iptal edebilsinmi
    init: function() {
      // Using a closure.
      var _this = this;

      // Setup the observer for the button.
      $("#clear-dropzone").on("click", function() {
        _this.removeAllFiles();
      });

    },
    success: function(file, response) {
      alert(response);
    },
    error: function(file, response) {
      alert(response);
    },

    accept: function(file, done) {//istenirse bu kısımdan daha dosya upload edilmeden extra bir bilgi sorglanabilir
      if (file.type != "image/jpeg" && file.type != "image/png") {
        return done("Tipi Uygun değildir");
      }
      return done();
    },
  }

}
</script>
</body>
<!-- END: Body-->
</html>
