<?php

	/* ckfinder ayarlari */
	unset($_SESSION['ckfinder']);
	//dosyaların olduğu yerin urli
	
	$_SESSION['ckfinder']['baseUrl'] = 'videosis/Panel/Pages/Dosyalar/';

	//baseurlin içindeki klasörlerin ayarlar
	$config[] = array(
		'name'              => 'Files', // Single quotes not allowed.
		'directory'         => 'files',
		'maxSize'           => 0,
		'allowedExtensions' => '7z,aiff,asf,avi,bmp,csv,doc,docx,fla,flv,gif,gz,gzip,jpeg,jpg,mid,mov,mp3,mp4,mpc,mpeg,mpg,ods,odt,pdf,png,ppt,pptx,pxd,qt,ram,rar,rm,rmi,rmvb,rtf,sdc,sitd,swf,sxc,sxw,tar,tgz,tif,tiff,txt,vsd,wav,wma,wmv,xls,xlsx,zip',
		'deniedExtensions'  => '',
		'backend'           => 'default'
	);

	$config[] = array(
		'name'              => 'Images',
		'directory'         => 'images',
		'maxSize'           => 0,
		'allowedExtensions' => 'bmp,gif,jpeg,jpg,png',
		'deniedExtensions'  => '',
		'backend'           => 'default'
	);
	
	$_SESSION['ckfinder']['resourceTypes']=$config;


	//baseurlnin altındaki dosyaların okuma yazma oluşturma gibi ayarları
	$config = array(
		'role'                => '*',
		'resourceType'        => '*',
		'folder'              => '/',

		'FOLDER_VIEW'         => true,
		'FOLDER_CREATE'       => true,
		'FOLDER_RENAME'       => true,
		'FOLDER_DELETE'       => true,

		'FILE_VIEW'           => true,
		'FILE_CREATE'         => true,
		'FILE_RENAME'         => true,
		'FILE_DELETE'         => true,

		'IMAGE_RESIZE'        => true,
		'IMAGE_RESIZE_CUSTOM' => true
	);
	
	$_SESSION['ckfinder']['accessControl']=$config;
	
?>

<!-- ckfinder -->
<section id="basic-form-layouts">
	<div class="row match-height">
		<div class="col-md-12">
			<div class="card">
				<div class="card-header">
					<h4 class="card-title" id="basic-layout-colored-form-control">Dosyalar</h4>
					<a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>					
				</div>
				<div class="card-content collapse show">
					<div class="card-body">	
					
						<div class="row">
							<div class="col-12">
								<div class="card">
									
									<div class="card-content collapse show">
									
									<!-- ckfinder -->
									  <div class="section-container">
										<div id="ckfinder-widget"></div>
									  </div>	
									<!-- /ckfinder -->
	
									</div>
								</div>
							</div>
						</div>
						
					</div>
				</div>
			</div>
		</div>
	</div>
</section>

<!-- ckfinder -->
<script src="./Pages/Ckfinder/ckfinder.js"></script>
<script>
      CKFinder.widget( 'ckfinder-widget', {
      	width: '100%',
      	height: 520,
      	rememberLastFolder: false
      } );
</script>
<!-- /ckfinder -->